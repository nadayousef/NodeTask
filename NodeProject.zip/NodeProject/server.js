require('dotenv').config();
const users=require('./routes/users');
const connection=require('./db')
const express = require("express");
const app = express();
 
app.use(express.json());

(async()=>await connection())();
app.use("/api/users",users);
app.use("/api/auth", require("./Authurization/Route"))
const PORT = process.env.PORT||5000;

app.listen(PORT, () =>console.log(`Server Connected to port ${PORT}...`));



// Handling Error
