const os = require('os');
var totmem=os.totalmem();
console.log(`tot : ${totmem}`);//another way to output to the console4
const eventemitter=require('events');// this class contains of many methods
const emitter =new eventemitter(); // instance of the class
const { emit } = require('process');

//register a listner when we make event called msglogged the lisnter is callled 
//the order is important becuse when we call th eevent it call all the listners 
emitter.on('msglogged',function(){
    console.log("ddj");
});

//Raised an event
emitter.emit('msglogged');//make a noise making event



const Logger=require('./logger');

const logger=new Logger();
logger.on('logging',(arg) =>{
console.log('listner called arg',arg);
});
logger.log('msg');

const http =require('http');
const server =http.createServer((req,res)=>{
if (req.url ==='/'){
    res.write('hello world');
    res.end();
}
if(req.url ==='/api/courses'){
    res.write(JSON.stringify([1,2,3]));
    res.end(); 
}
});

