// for login msgs
var url='http://mylogger.io/log';
const eventemitter=require('events');// this class contains of many methods

class Logger extends eventemitter{
    
     log(message){
    
        console.log(message);
        this.emit('logging',{id:1,url:'hshs'});
    }
}
module.exports=Logger;